﻿using MedicalLaboratory.DataBase;
using MedicalLaboratory.WindowGroup;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MedicalLaboratory
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        LaboratoryEntities entities = new LaboratoryEntities();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AuthorizationButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //проверка на пустые поля ввода
                if (LoginInput.Text == string.Empty ||
                    PasswordInputHidden.Password == string.Empty)
                {
                    MessageBox.Show("Не все поля заполнены!");
                    return;
                }
                string login = LoginInput.Text;
                string password = PasswordInputHidden.Password;

                //проверка соответсвтия пароля и логина пользователя
                var checkUser = entities.Users.FirstOrDefault(x => x.Login == login
                && x.Password == password);

                if (checkUser == null)
                {
                    MessageBox.Show("Неверный логин или пароль!");
                    return;
                }

                //разграничение прав доступа
                if (checkUser.IdTypeUsers == 1)
                {
                    MessageBox.Show("Вы лаборант, " + $"{checkUser.Surname}" +
                        $" {checkUser.Name}");
                    return;
                }
                if (checkUser.IdTypeUsers == 2)
                {
                    MessageBox.Show("Вы бухгалтер, " + $"{checkUser.Surname}" +
                        $" {checkUser.Name}");
                    return;
                }
                if (checkUser.IdTypeUsers == 3)
                {
                    LoginHistoryWindow loginHistoryWindow = new LoginHistoryWindow();
                    loginHistoryWindow.Show();
                    this.Close();
                }
            }
            catch { }            
        }

        private void CheckPassword_Click(object sender, RoutedEventArgs e)
        {
            //просмотр скрытого пароля и наоборот
            if (PasswordInputHidden.Visibility == Visibility.Visible)
            {
                PasswordInputVisible.Text = PasswordInputHidden.Password;
                PasswordInputVisible.Visibility = Visibility.Visible;
                PasswordInputHidden.Visibility = Visibility.Hidden;
                return;
            }
            if (PasswordInputVisible.Visibility == Visibility.Visible)
            {
                PasswordInputHidden.Password = PasswordInputVisible.Text;
                PasswordInputHidden.Visibility = Visibility.Visible;
                PasswordInputVisible.Visibility = Visibility.Hidden;
                return;
            }
        }
    }
}
