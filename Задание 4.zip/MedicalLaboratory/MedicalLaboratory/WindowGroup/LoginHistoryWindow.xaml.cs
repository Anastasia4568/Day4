﻿using MedicalLaboratory.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalLaboratory.WindowGroup
{
    /// <summary>
    /// Логика взаимодействия для LoginHistoryWindow.xaml
    /// </summary>
    public partial class LoginHistoryWindow : Window
    {
        LaboratoryEntities entities = new LaboratoryEntities();
        public LoginHistoryWindow()
        {
            InitializeComponent();

            //вывод информации об истории входа пользователей
            LoginHistoryOutput.ItemsSource = entities.Users.ToList();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void SearchInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            //поиск пользователей по логину
             LoginHistoryOutput.ItemsSource = entities.Users.Where(x => x.Login.ToLower().
                    Contains(SearchInput.Text.ToLower())).ToList();
        }
    }
}
